//
//  moveMentorPhoneTestApp.swift
//  moveMentorPhoneTest
//
//  Created by Kaleb Lee on 3/19/25.
//

import SwiftUI

@main
struct moveMentorPhoneTestApp: App {
    
    var body: some Scene {
        
        WindowGroup {
            ContentView(registrationData: RegistrationData())
        }
    }
}
