import Foundation

enum Algorithm {
    case single
    case multiple
}
