//
//  moveMentorPhoneTestTests.swift
//  moveMentorPhoneTestTests
//
//  Created by Kaleb Lee on 3/19/25.
//

import Testing
@testable import moveMentorPhoneTest

struct moveMentorPhoneTestTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
